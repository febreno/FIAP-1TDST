package br.com.fiap.conexao;

public class Dados {

    public static final String USER = "RM94513";
    public static final String PASSWORD = "210902";

}

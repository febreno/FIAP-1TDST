package br.com.fiap.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.bo.PessoaBO;
import br.com.fiap.bo.PessoaService;
import br.com.fiap.to.PessoaTO;

@Path("/pessoa")
public class PessoaController {
	
	PessoaService ps = new PessoaBO();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<PessoaTO> buscar() {
		return ps.buscar();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public PessoaTO buscar(@PathParam("id") Long id) {
		return ps.buscar(id);
	}
//
////	@POST
////	@Consumes(MediaType.APPLICATION_JSON)
////	public Response cadastrar(ProdutoTO produto, @Context UriInfo uriInfo) {
////
////		// INSERIR NA BASE
////		pb.cadastrar(produto);
////
////		// CONSTRUIR O PATH DE RETORNO
////		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
////		builder.path(Integer.toString(produto.getCodigo()));
////
////		// RETORNA O PATH E O STATUS 201
////		return Response.created(builder.build()).build();
////	}
//	
//	@POST
//	@Consumes(MediaType.APPLICATION_JSON)
//	public Response cadastrarPessoa(PessoaTO pessoa, @Context UriInfo uriInfo) {
//
//		// INSERIR NA BASE
//		pb1.insert(pessoa);
//
//		// CONSTRUIR O PATH DE RETORNO
//		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
//		builder.path("Criado");
//
//		// RETORNA O PATH E O STATUS 201
//		return Response.created(builder.build()).build();
//	}
//
//	@PUT
//	@Path("/{id}")
//	@Consumes(MediaType.APPLICATION_JSON)
//	public Response atualiza(ProdutoTO produto, @PathParam("id") int id) {
//		produto.setCodigo(id);
//		pb.atualiza(produto);
//		return Response.ok().build();
//	}
//
//	@DELETE
//	@Path("/{id}")
//	public void excluir(@PathParam("id") int id) {
//		pb.remover(id);
//	}

}


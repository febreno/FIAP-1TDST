package br.com.revisao;

public class Revisao {

	public static void main(String[] args) {
		
	     	int idade = 5; //valor inteiro
	        float altura = 1.79f; //valor quebrado
	        double peso = 80.22; //valor quebrado (sempre usar "." ao inv�s de  "," )
	        char sexo = 'M';
	        boolean fumanteStatus = false;
	        String nome = "Jo�o";
    
	        System.out.println("Ol�, meu nome � "+ nome);
	        System.out.println("Sou fumante? "+ fumanteStatus);
	        System.out.println("Tenho "+ altura + " de altura e peso " + peso + "kg");
        // Se quiser treinar imprima uma frase dizendo qual � seu peso. 

	}

}

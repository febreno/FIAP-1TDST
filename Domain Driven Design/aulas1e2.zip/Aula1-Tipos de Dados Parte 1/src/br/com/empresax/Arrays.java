package br.com.empresax;

import java.util.ArrayList;

public class Arrays {

	public static void main(String[] args) {

		int idade = 5;
		// Tipo array, usado para lista de usuarios, lista de produtos etc
		ArrayList<String> listinha = new ArrayList<>();
		listinha.add("Topico 1 da lista me achou");
		listinha.add("Topico 2 da lista me achou");

		// tipo apelido listadecima get = pegar 0 (1)
		String captura0 = listinha.get(0);
		System.out.println(captura0);
	}
}

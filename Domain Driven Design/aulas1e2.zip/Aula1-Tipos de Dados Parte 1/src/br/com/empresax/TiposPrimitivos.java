package br.com.empresax;

public class TiposPrimitivos {

	public static void main(String[] args) {
	
		
		 //tipo apelido = valor
	    // vari�vel sempre com letra maiucsulas
        //tipo variavel  = valor 
	     	int myNum = 5;
	        float myFloatNum = 5.99f;
	        float myFloatNumTeste = (float) 5.99;
	        double myDoubleNum = 5.99;
	        double myDoubleNum2 = 5.99d; // mais precisa, ocupa mais espa�o
	        char myLetter = 'D';
	        boolean myBool = true;
	        String myString = "Hello";
     
	        System.out.print(myNum);
	        System.out.println(myFloatNum);
	        System.out.println(myFloatNumTeste);
	        System.out.println(myDoubleNum);
	        System.out.println(myDoubleNum2);
	        System.out.println(myLetter);
	        System.out.println(myBool);
	        System.out.println(myString);

	}

}

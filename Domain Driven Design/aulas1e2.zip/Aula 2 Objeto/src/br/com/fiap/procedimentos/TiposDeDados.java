package br.com.fiap.procedimentos;
//bibliotecas 
import java.util.Calendar;

public class TiposDeDados {

	public static void main(String[] args) {
	//TODO
	int idade = 5;
	float altura = 1.78f;
	double peso = 60;
	char sexo = 'f';
	String cidade = "S�o Paulo";	
	boolean statusFumante = true;  //camelCase   primeraSegunda
	Calendar calendario_1 = Calendar.getInstance();
	System.out.println(calendario_1);
	System.out.println("Ol�, minha idade � " + idade);
	System.out.println("Ol�, minha altura � " + altura);
	System.out.println("Ol�, minha cidade � " + cidade);
	System.out.println("-".repeat(50));
	System.out.println(calendario_1.getTime());   //igual
	calendario_1.add(Calendar.MONTH, 2);
	System.out.println(calendario_1.getTime());  //igual
	
	}
}

package br.com.fiap.procedimentos;

import java.util.Date;

public class BoasVindas {

	public static void comprimentarCliente() {
		System.out.println("Bom dia");

		Date data = new Date();
		System.out.print("S�o Paulo, : " + data);
	}

	public static void reconhecerCliente() {
		String nome = "Jo�o";
		System.out.println("Bem vindo!");
		System.out.println("Ol�" + nome + "tudo bem? \n, voc� mora em S�o Paulo");

	}

	public static void main(String[] args) {
		// aqui come�a a parte que o programa executa
		comprimentarCliente();
		reconhecerCliente();
	}

}

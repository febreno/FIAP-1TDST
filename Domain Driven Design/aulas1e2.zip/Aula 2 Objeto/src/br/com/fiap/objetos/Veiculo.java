package br.com.fiap.objetos;
public class Veiculo {
	
	public String cor;
	public String modelo;
	
    public void iniciar() {
        System.out.println("Ligando veiculo");
    }

    public void frear() {
        System.out.println("Freando veiculo");
    }
    
    public void ligarParabrisa() {
        System.out.println("Ligando Parabrisa");
    }
}

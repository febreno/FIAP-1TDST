package br.com.fiap.objetos;

public class Carro extends Veiculo{
	
	//procedimento iniciar
    public void iniciar() {
        System.out.println("Ligando carro");
    }
  //procedimento freat
    public void frear() {
        System.out.println("Freando carro");
    }
}

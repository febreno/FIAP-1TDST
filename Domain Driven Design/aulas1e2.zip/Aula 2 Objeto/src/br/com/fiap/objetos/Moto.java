package br.com.fiap.objetos;

public class Moto extends Veiculo{
	
	
    public void iniciar() {
        System.out.println("Ligando moto");
    }

    public void andar() {
        System.out.println("Acelerando moto");
    }

    public void frear() {
        System.out.println("Freando moto");
    }
}

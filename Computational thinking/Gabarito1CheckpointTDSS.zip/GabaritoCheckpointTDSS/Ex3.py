num_a = float(input("Informe 1º nº: "))
num_b = float(input("Informe 2º nº: "))
num_c = float(input("Informe 3º nº: "))
num_d = float(input("Informe 4º nº: "))

produto = num_a * num_b * num_c * num_d

media_geometrica = produto ** (1 / 4)

print("A media geométrica vale ", media_geometrica)

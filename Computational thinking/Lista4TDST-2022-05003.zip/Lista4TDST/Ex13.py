import random

sorteado = random.randint(1, 1000)
tentativas = 0

chute = int(input("Chute: "))
while chute != sorteado:
    if chute < sorteado:
        print("Tente um número maior!")
    elif chute > sorteado:
        print("Tente um número menor!")    
    tentativas = tentativas + 1
    chute = int(input("Chute: "))

print("Parabéns, você acertou em ", tentativas)
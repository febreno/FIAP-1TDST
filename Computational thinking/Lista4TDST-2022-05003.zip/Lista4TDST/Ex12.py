num = int(input("Informe o numero: "))
num_bkp = num
soma = 0

while num != 0:
    r = num % 10
    num = num // 10
    soma = soma * 10 + r

print(soma)  
if soma == num_bkp:
    print("Palindrome!")  
else:
    print("Nao e palindrome!")    

def mmc(a, b):
    mult = a
    while mult % a != 0 or mult % b != 0:
        mult = mult + 1

    return mult

r = mmc(6, 8)
print(r)    
#include <stdio.h>
//passagem de parâmetros por valor
int divisaoPorValor(int a,  int b) {
    int resp = a / b;
    a = a + 1;
    b = b + 1;
    return resp;
}

//passagem de parâmetros por referência
int divisaoPorRef(int *a, int *b) {
    int resp = *a / *b;
    *a = *a + 1;
    *b = *b + 1;
    return resp;
}

int main() {
    int x = 5;
    int y = 3;
    int r = divisaoPorRef(&x, &y);
    printf("Resultado: %d\n", r);
    printf("X: %d\n", x);
    printf("Y: %d\n", y);
}
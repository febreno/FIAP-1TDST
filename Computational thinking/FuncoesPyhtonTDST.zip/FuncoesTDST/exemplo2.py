#Exemplo de passagem de valores em Python

def divisao(a, b):
    aux = a // b, a % b
    a = a + 1
    b = b + 1
    return aux


x = 5
y = 3
resp = divisao(x, y)
print(resp)
print(x)
print(y)

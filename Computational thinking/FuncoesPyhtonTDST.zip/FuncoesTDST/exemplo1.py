def divisao(a, b):
    return a // b, a % b



resp = divisao(5, 3)
print(resp)

